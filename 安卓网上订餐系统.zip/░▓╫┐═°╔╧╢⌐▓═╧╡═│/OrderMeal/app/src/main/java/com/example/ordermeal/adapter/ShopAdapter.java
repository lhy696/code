package com.example.ordermeal.adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.example.ordermeal.R;
import com.example.ordermeal.activity.ShopDetailActivity;
import com.example.ordermeal.bean.ShopBean;

import java.util.List;

public class ShopAdapter extends BaseAdapter {
    private Context mContext;
    private List<ShopBean> sb1;
    public ShopAdapter(Context mContext) {
        this.mContext = mContext;
    }
//设置数据更新界面
    public void setData(List<ShopBean> sb1){
        this.sb1=sb1;
        notifyDataSetChanged();

    }
    @Override
    public int getCount() {
        return sb1==null?0:sb1.size();
    }

    @Override
    public ShopBean getItem(int position) {
        //根据position得到对应item的对象
        return sb1==null?null:sb1.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        //得到对应的position的item视图，position是当前的item的位置，convert view参数是滚出屏幕的item的view
       final ViewHolder vh;//存储每个列表项的视图组件
       //复用convert View
        if(convertView==null){
            vh=new ViewHolder();
            //从给定的XML布局文件（R.layout.shop_item）动态创建一个新的视图实例，并将这个新创建或复用的视图赋值给convertView变量。
            convertView= LayoutInflater.from(mContext).inflate(R.layout.shop_item,null);
            vh.tv_shop_name=(TextView)convertView.findViewById(R.id.tv_shop_name);
            vh.tv_sale_num=(TextView)convertView.findViewById(R.id.tv_sale_num);
            vh.tv_welfare=(TextView)convertView.findViewById(R.id.tv_welfare);
            vh.tv_time=(TextView)convertView.findViewById(R.id.tv_time);
            vh.tv_cost=(TextView)convertView.findViewById(R.id.tv_cost);
            vh.iv_shop_pic=(ImageView)convertView.findViewById(R.id.iv_shop_pic);
            convertView.setTag(vh);//将视图标签vh设置到convertView视图上，方便检索
        }else{
            vh=(ViewHolder)convertView.getTag();//从convertView获取已创建的viewholder
        }
        //获取position对应的item的数据对象
        final ShopBean bean=getItem(position);
        if(bean!=null){
            vh.tv_shop_name.setText(bean.getShopName());
            vh.tv_sale_num.setText("月售"+bean.getSaleNum());
            vh.tv_cost.setText("起送￥"+bean.getOfferPrice()+"|配送￥"+bean.getDistributionCost());
            vh.tv_time.setText(bean.getTime());
            vh.tv_welfare.setText(bean.getWelfare());
            //使用glide库加载imageview的图片
            Glide.with(mContext)
                    .load(bean.getShopPic())
                    .error(R.mipmap.ic_launcher)
                    .into(vh.iv_shop_pic);
        }
        //给每个item设置点击事件
        convertView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(bean==null)return;
                Intent intent=new Intent(mContext, ShopDetailActivity.class);
                intent.putExtra("shop",bean);//传递该列表项的数据对象
                mContext.startActivity(intent);
            }
        });
        return convertView;
    }
    class ViewHolder{
        public TextView tv_shop_name,tv_sale_num,tv_cost,tv_welfare,tv_time;
        public ImageView iv_shop_pic;
    }
}
