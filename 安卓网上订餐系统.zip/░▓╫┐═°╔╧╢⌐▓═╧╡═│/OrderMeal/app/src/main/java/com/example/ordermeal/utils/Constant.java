package com.example.ordermeal.utils;

public class Constant {
    public static final String WEB_SITE="http://192.168.112.118:7070/order";//内网接口
    public static final String REQUEST_SHOP_URL="/shop_list_data.json";//店铺列表接口

}
